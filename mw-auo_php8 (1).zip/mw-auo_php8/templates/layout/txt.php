<?php echo $this->fetch('content'); ?>
