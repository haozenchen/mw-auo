<div>
	<textarea style="width: 100%;height: 100%;" readonly><?php echo $msg?></textarea>
</div>